<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


$config['appId']   = '1592834727608126';
$config['secret']  = 'a6c945cb6738c4233fab82e6799893b1';
$config["cookie"]	=	true;
$config["oauth"]	=	true;

?>
