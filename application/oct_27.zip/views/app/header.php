  <header id="header">
            <center>
        	 <!-- /32361281/DFP_BEHRENTZ_SPORTSHUB_728X90_1 -->
            <div id='div-gpt-ad-1505826037322-5' style='height:90px; width:728px;'>
            <script>
            googletag.cmd.push(function() { googletag.display('div-gpt-ad-1505826037322-5'); });
            </script>
            </div>
		</center>

  <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button"> <span class="sr-only">Toggle navigation</span> </a>
    <div class="container">
      <div class="logo"><a href="#"><img src="<?php echo base_url();?>images/logo.png"></a></div>
    </div>
  </header>
  <!-- close header -->
