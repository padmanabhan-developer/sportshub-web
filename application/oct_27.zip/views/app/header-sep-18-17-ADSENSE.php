  <header id="header">
            <center>
        	<?php $ad_random = rand(1,10);?>
            <!-- SH365_Leaderboard -->
            <ins class="adsbygoogle"
                 style="display:inline-block;width:728px;height:90px"
                 data-ad-client="ca-pub-9427943540446316"
                 data-ad-slot="6688987852"></ins>
            <script>
            (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
		</center>

  <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button"> <span class="sr-only">Toggle navigation</span> </a>
    <div class="container">
      <div class="logo"><a href="#"><img src="<?php echo base_url();?>images/logo.png"></a></div>
    </div>
  </header>
  <!-- close header -->
