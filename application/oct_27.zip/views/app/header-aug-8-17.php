  <header id="header">
            <center>
        	<?php $ad_random = rand(1,10);?>
            <a href="javascript:;" class="header_ad"><img src="<?php echo base_url();?>/images/ads/728_90_<?php echo $ad_random?>.jpg"></a>
		</center>

  <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button"> <span class="sr-only">Toggle navigation</span> </a>
    <div class="container">
      <div class="logo"><a href="#"><img src="<?php echo base_url();?>images/logo.png"></a></div>
    </div>
  </header>
  <!-- close header -->
