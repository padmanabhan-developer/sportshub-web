<input type="hidden" value="<?php echo $channel_id;?>" id="total_channel_ids" >
<div class="events-inner" id="show_fixture">
	<?php $this->load->view('app/display-fixture');?>                       
</div> <!-- close events-inner -->


