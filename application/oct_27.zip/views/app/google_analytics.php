<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-70072811-1', 'auto');
  ga('send', 'pageview');

</script>


<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');

fbq('init', '987789627966283');
fbq('track', "PageView");</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=987789627966283&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->

<script async='async' src='https://www.googletagservices.com/tag/js/gpt.js'></script>
<script>
  var googletag = googletag || {};
  googletag.cmd = googletag.cmd || [];
</script>

<script>
  googletag.cmd.push(function() {
    googletag.defineSlot('/32361281/DFP_BEHRENTZ_SPORTSHUB_160X600_1', [160, 600], 'div-gpt-ad-1505826037322-0').addService(googletag.pubads());
    googletag.defineSlot('/32361281/DFP_BEHRENTZ_SPORTSHUB_160X600_2', [160, 600], 'div-gpt-ad-1505826037322-1').addService(googletag.pubads());
    googletag.defineSlot('/32361281/DFP_BEHRENTZ_SPORTSHUB_160X600_3_STICKY', [160, 600], 'div-gpt-ad-1505826037322-2').addService(googletag.pubads());
    googletag.defineSlot('/32361281/DFP_BEHRENTZ_SPORTSHUB_300X250_1', [300, 250], 'div-gpt-ad-1505826037322-3').addService(googletag.pubads());
    googletag.defineSlot('/32361281/DFP_BEHRENTZ_SPORTSHUB_300X250_2_STICKY', [300, 250], 'div-gpt-ad-1505826037322-4').addService(googletag.pubads());
    googletag.defineSlot('/32361281/DFP_BEHRENTZ_SPORTSHUB_728X90_1', [728, 90], 'div-gpt-ad-1505826037322-5').addService(googletag.pubads());
    googletag.defineSlot('/32361281/DFP_BEHRENTZ_SPORTSHUB_728X90_2', [728, 90], 'div-gpt-ad-1505826037322-6').addService(googletag.pubads());
    googletag.pubads().enableSingleRequest();
    googletag.pubads().collapseEmptyDivs();
    googletag.enableServices();
  });
</script>