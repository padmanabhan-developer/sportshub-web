 <ul class="sidebar-menu">
            <!--<li class="header">MAIN NAVIGATION</li>-->
            <li class="treeview">
              <a href="<?php echo base_url();?>admin/dashboard">
                <i class="menu-icon1"></i> <span>Dashboard</span> 
              </a>
            </li>
            <li class="treeview">
              <a href="<?php echo base_url();?>admin/admin_user">
                <i class="menu-icon2"></i> <span>Admin Users</span> 
              </a>
            </li>
            <li class="treeview">
              <a href="<?php echo base_url();?>admin/matches">
                <i class="menu-icon2"></i> <span>Matches</span> 
              </a>
            </li>
            <li class="treeview">
              <a href="<?php echo base_url();?>admin/establishments">
                <i class="menu-icon3"></i> <span>Establishments</span> 
              </a>
            </li>
            <li class="treeview">
              <a href="<?php echo base_url();?>admin/user">
                <i class="menu-icon2"></i> <span>APP Users</span> 
              </a>
            </li>
            <li class="treeview">
              <a href="<?php echo base_url();?>admin/rating_comment">
                <i class="menu-icon4"></i> <span>Rating / Comments</span> 
              </a>
            </li>
            <li class="treeview">
              <a href="<?php echo base_url();?>admin/slider">
                <i class="menu-icon4"></i> <span>Slider</span> 
              </a>
            </li>
             <li class="treeview">
              <a href="#">
                <i class="menu-icon7"></i> <span>Payment</span> 
              </a>
            </li>
              <!--<li class="treeview">
              <a href="javascript:void();">
                <i class="menu-icon8"></i> <span>Communication</span> 
              </a>
              <ul class="treeview-menu menu-open" style="display: block;">
                <li><a href="#"></i>- Automation</a>
                <li><a href="#"></i>- Campaigns</a>
                </li>
              </ul>
            </li>-->
            <li class="treeview">
              <a href="#">
                <i class="menu-icon9"></i> <span>Advertisement</span> 
              </a>
            </li>  
            <li class="treeview">
              <a href="https://analytics.google.com/analytics/web/?et&authuser=0#report/visitors-overview/a70118948w107294902p111758123/" target="_blank">
                <i class="menu-icon10"></i> <span>Analytics</span> 
              </a>
            </li>  
            <li class="treeview">
              <a href="<?php echo base_url();?>admin/quiz">
                <i class="menu-icon10"></i> <span>Quiz</span> 
              </a>
            </li>
            <li class="treeview">
              <a href="<?php echo base_url();?>admin/logout">
                <i class="menu-icon6"></i> <span>Logout</span> 
              </a>
            </li>  
            
            </ul>