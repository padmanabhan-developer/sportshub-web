<div id="header">
     	  <div class="container">
          	   <div class="logo"><a href="<?php echo base_url();?>"><img src="<?php echo base_url();?>images/logo.png" /></a></div>
               <div class="header_right">
               <span class="nav_title">SPORTSLOVERS:</span>
               <div class="menu">
                    <div class="nav-1 nav-collapse">
                      <ul id="main-menu" class="sm sm-blue">
                      	<li><a href="<?php echo base_url();?>promotion/findmatch" class="highlighted" >Find Bars</a></li>
                        <li><a href="<?php echo base_url();?>app" >Personal planner</a></li>
                        <li><a href="<?php echo base_url();?>recommendbar" >Recommend a Bar</a></li>
                        <li><a href="<?php echo base_url();?>quiz" >Quiz</a></li>
                        <li class="devider"></li>
                        <li><a href="<?php echo base_url();?>app/signup">signup</a>
                        </li>
                        <li><a href="<?php echo base_url();?>app/login">login</a>
                        </li>
                      </ul>
                      </div>
                    </div>
               </div><!--close header_right-->
          </div><!--close container-->
     </div>