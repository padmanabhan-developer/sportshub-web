<div id="footer">
     	  <div class="container">
          	   <div class="logo_footer"><a href="<?php echo base_url();?>"><img src="<?php echo base_url();?>images/logo.png" /></a></div>
               <p>contact us at <a href="#">info@sportshub365.com</a></p>
          </div><!--close container-->
     </div><!--close footer-->